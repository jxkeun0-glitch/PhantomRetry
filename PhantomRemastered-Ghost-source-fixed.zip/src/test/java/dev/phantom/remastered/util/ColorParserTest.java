package dev.phantom.remastered.util;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class ColorParserTest {
    @Test
    void parsesWithAndWithoutHashPrefix() {
        assertEquals(0x8B5CF6, ColorParser.parseHex("#8B5CF6"));
        assertEquals(0x102030, ColorParser.parseHex("102030"));
    }

    @Test
    void rejectsInvalidColorValues() {
        assertThrows(IllegalArgumentException.class, () -> ColorParser.parseHex("#123"));
        assertThrows(IllegalArgumentException.class, () -> ColorParser.parseHex("not-a-color"));
    }
}
