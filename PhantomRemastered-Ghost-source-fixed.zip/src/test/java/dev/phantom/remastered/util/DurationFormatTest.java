package dev.phantom.remastered.util;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class DurationFormatTest {
    @Test
    void formatsMinutesAndSeconds() {
        assertEquals("00:00", DurationFormat.formatSeconds(0));
        assertEquals("02:05", DurationFormat.formatSeconds(125));
    }

    @Test
    void includesHoursWhenNeededAndClampsNegativeInput() {
        assertEquals("1:01:01", DurationFormat.formatSeconds(3661));
        assertEquals("00:00", DurationFormat.formatSeconds(-10));
    }
}
