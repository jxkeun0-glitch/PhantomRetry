package dev.phantom.remastered.module.impl;

import dev.phantom.remastered.module.HudModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.Text;

public final class FpsModule extends HudModule {
    public FpsModule() {
        super("fps", "FPS Counter", "Displays the current client frame rate.", 12, 48);
    }

    @Override
    public void renderHud(MinecraftClient client, DrawContext context, RenderTickCounter tickCounter) {
        String label = "FPS  " + client.getCurrentFps();
        int width = client.textRenderer.getWidth(label);
        context.fill(x() - 5, y() - 3, x() + width + 7, y() + 13, 0xB0101220);
        context.drawTextWithShadow(client.textRenderer, Text.literal(label), x(), y(), 0xFFE8E4FF);
    }
}
