package dev.phantom.remastered.module.impl;

import dev.phantom.remastered.module.HudModule;
import dev.phantom.remastered.setting.BooleanSetting;
import dev.phantom.remastered.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.LivingEntity;
import net.minecraft.text.Text;
import net.minecraft.util.hit.EntityHitResult;

/** A practice indicator only: it never clicks or attacks. */
public final class TriggerBotTrainerModule extends HudModule {
    private final NumberSetting range = addSetting(new NumberSetting("range", "Target Range", 4.0, 1.0, 8.0, 0.5));
    private final BooleanSetting playersOnly = addSetting(new BooleanSetting("players_only", "Players Only", false));
    private final BooleanSetting showDistance = addSetting(new BooleanSetting("show_distance", "Show Distance", true));

    private String targetLabel = "No target";
    private double targetDistance = -1;

    public TriggerBotTrainerModule() {
        super("triggerbot_trainer", "TriggerBot Trainer", "Shows target and range information for manual practice; never attacks or clicks.", 12, 224);
    }

    @Override
    public void tick(MinecraftClient client) {
        targetLabel = "No target";
        targetDistance = -1;
        if (client.player == null || !(client.crosshairTarget instanceof EntityHitResult hit)
                || !(hit.getEntity() instanceof LivingEntity living) || !living.isAlive()) {
            return;
        }
        if (playersOnly.value() && !(living instanceof net.minecraft.entity.player.PlayerEntity)) {
            return;
        }
        targetDistance = client.player.distanceTo(living);
        if (targetDistance <= range.value()) {
            targetLabel = living.getName().getString();
        }
    }

    @Override
    public void renderHud(MinecraftClient client, DrawContext context, RenderTickCounter tickCounter) {
        String first = "TRIGGER TRAINER  " + (targetDistance >= 0 && targetDistance <= range.value() ? "TARGET" : "IDLE");
        String second = targetLabel;
        if (showDistance.value() && targetDistance >= 0 && targetDistance <= range.value()) {
            second += String.format(java.util.Locale.ROOT, "  %.1fm", targetDistance);
        }
        int width = Math.max(client.textRenderer.getWidth(first), client.textRenderer.getWidth(second));
        context.fill(x() - 5, y() - 4, x() + width + 7, y() + 27, 0xB0101220);
        context.drawTextWithShadow(client.textRenderer, Text.literal(first), x(), y(), 0xFFBBA8FF);
        context.drawTextWithShadow(client.textRenderer, Text.literal(second), x(), y() + 12, 0xFFE8E4FF);
    }

    @Override protected String defaultGhostCategory() { return "Combat"; }
    @Override protected String defaultCrystalCategory() { return "Combat Information"; }
    @Override protected String defaultRageCategory() { return "Combat Information"; }
}
