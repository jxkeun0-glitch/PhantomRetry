package dev.phantom.remastered.module.impl;

import dev.phantom.remastered.module.HudModule;
import dev.phantom.remastered.util.DurationFormat;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.Text;

public final class PracticeTimerModule extends HudModule {
    private long startedAtMillis;

    public PracticeTimerModule() {
        super("practice_timer", "Practice Timer", "Shows elapsed time since the timer was enabled.", 12, 194);
    }

    @Override
    protected void onEnable() {
        startedAtMillis = System.currentTimeMillis();
    }

    @Override
    public void renderHud(MinecraftClient client, DrawContext context, RenderTickCounter tickCounter) {
        long elapsedSeconds = Math.max(0, (System.currentTimeMillis() - startedAtMillis) / 1000);
        String label = "PRACTICE  " + DurationFormat.formatSeconds(elapsedSeconds);
        int width = client.textRenderer.getWidth(label);
        context.fill(x() - 5, y() - 3, x() + width + 7, y() + 13, 0xB0101220);
        context.drawTextWithShadow(client.textRenderer, Text.literal(label), x(), y(), 0xFFE8E4FF);
    }

    @Override
    protected String defaultGhostCategory() {
        return "Miscellaneous";
    }

    @Override
    protected String defaultCrystalCategory() {
        return "Crystal Practice";
    }

    @Override
    protected String defaultRageCategory() {
        return "Practice";
    }
}
