package dev.phantom.remastered.module;

import com.google.gson.JsonObject;
import dev.phantom.remastered.PhantomRemasteredClient;
import dev.phantom.remastered.gui.GuiStyle;
import dev.phantom.remastered.module.impl.ArmorHudModule;
import dev.phantom.remastered.module.impl.AutoMaceTrainerModule;
import dev.phantom.remastered.module.impl.CoordinatesModule;
import dev.phantom.remastered.module.impl.FpsModule;
import dev.phantom.remastered.module.impl.PotionEffectsModule;
import dev.phantom.remastered.module.impl.PracticeTimerModule;
import dev.phantom.remastered.module.impl.ToggleSprintModule;
import dev.phantom.remastered.module.impl.TriggerBotTrainerModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class ModuleManager {
    private final List<PhantomModule> modules = new ArrayList<>();
    private final Set<Integer> pressedLastTick = new HashSet<>();

    public ModuleManager() {
        modules.add(new CoordinatesModule());
        modules.add(new FpsModule());
        modules.add(new ArmorHudModule());
        modules.add(new PotionEffectsModule());
        modules.add(new ToggleSprintModule());
        modules.add(new PracticeTimerModule());
        modules.add(new TriggerBotTrainerModule());
        modules.add(new AutoMaceTrainerModule());
    }

    public List<PhantomModule> all() {
        return List.copyOf(modules);
    }

    public List<PhantomModule> inCategory(GuiStyle style, String category) {
        return modules.stream()
                .filter(module -> module.category(style).equals(category))
                .toList();
    }

    public PhantomModule byId(String id) {
        return modules.stream().filter(module -> module.id().equals(id)).findFirst().orElse(null);
    }

    public void tick(MinecraftClient client) {
        handleModuleKeybinds(client);
        for (PhantomModule module : modules) {
            if (module.enabled()) {
                module.tick(client);
            }
        }
    }

    private void handleModuleKeybinds(MinecraftClient client) {
        if (client.getWindow() == null || client.currentScreen != null) {
            pressedLastTick.clear();
            return;
        }
        var window = client.getWindow();
        Set<Integer> pressedNow = new HashSet<>();
        for (PhantomModule module : modules) {
            int key = module.keybind();
            if (key <= GLFW.GLFW_KEY_UNKNOWN) {
                continue;
            }
            if (InputUtil.isKeyPressed(window, key)) {
                pressedNow.add(key);
                if (!pressedLastTick.contains(key)) {
                    module.setEnabled(!module.enabled());
                    if (PhantomRemasteredClient.CONFIG != null) {
                        PhantomRemasteredClient.CONFIG.saveProfile(PhantomRemasteredClient.CONFIG.getActiveProfile());
                    }
                }
            }
        }
        pressedLastTick.clear();
        pressedLastTick.addAll(pressedNow);
    }

    public void renderHud(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        for (PhantomModule module : modules) {
            if (module.enabled()) {
                module.renderHud(client, context, tickCounter);
            }
        }
    }

    public JsonObject toJson() {
        JsonObject json = new JsonObject();
        for (PhantomModule module : modules) {
            json.add(module.id(), module.toJson());
        }
        return json;
    }

    public void loadJson(JsonObject json) {
        for (PhantomModule module : modules) {
            if (json.has(module.id()) && json.get(module.id()).isJsonObject()) {
                module.fromJson(json.getAsJsonObject(module.id()));
            }
        }
    }

    public void resetHudLayout() {
        for (PhantomModule module : modules) {
            if (module instanceof HudModule hudModule) {
                hudModule.resetPosition();
            }
        }
    }
}
