package dev.phantom.remastered.module.impl;

import dev.phantom.remastered.module.HudModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.Text;

public final class CoordinatesModule extends HudModule {
    public CoordinatesModule() {
        super("coordinates", "Coordinates", "Shows position and compass direction.", 12, 12);
    }

    @Override
    public void renderHud(MinecraftClient client, DrawContext context, RenderTickCounter tickCounter) {
        if (client.player == null) {
            return;
        }
        String coordinates = String.format(
                "XYZ  %.1f  %.1f  %.1f",
                client.player.getX(),
                client.player.getY(),
                client.player.getZ()
        );
        String facing = "FACING  " + client.player.getHorizontalFacing().asString().toUpperCase();
        drawLines(client, context, coordinates, facing);
    }

    private void drawLines(MinecraftClient client, DrawContext context, String first, String second) {
        int width = Math.max(client.textRenderer.getWidth(first), client.textRenderer.getWidth(second));
        context.fill(x() - 5, y() - 4, x() + width + 7, y() + 24, 0xB0101220);
        context.fill(x() - 5, y() - 4, x() - 2, y() + 24, 0xFF8B5CF6);
        context.drawTextWithShadow(client.textRenderer, Text.literal(first), x() + 3, y(), 0xFFF3F0FF);
        context.drawTextWithShadow(client.textRenderer, Text.literal(second), x() + 3, y() + 11, 0xFFBBA8FF);
    }
}
