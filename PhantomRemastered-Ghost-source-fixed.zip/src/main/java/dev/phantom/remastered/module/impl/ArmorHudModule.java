package dev.phantom.remastered.module.impl;

import dev.phantom.remastered.module.HudModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

import java.util.List;

public final class ArmorHudModule extends HudModule {
    public ArmorHudModule() {
        super("armor_hud", "Armor Durability", "Shows remaining durability for equipped armor.", 12, 72);
    }

    @Override
    public void renderHud(MinecraftClient client, DrawContext context, RenderTickCounter tickCounter) {
        if (client.player == null) {
            return;
        }
        int lineY = y();
        context.fill(x() - 5, y() - 4, x() + 150, y() + 56, 0xB0101220);
        context.drawTextWithShadow(client.textRenderer, Text.literal("ARMOR"), x(), lineY, 0xFFBBA8FF);
        lineY += 12;
        for (EquipmentSlot slot : List.of(
                EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
        )) {
            ItemStack stack = client.player.getEquippedStack(slot);
            String itemName = stack.isEmpty() ? "Empty" : stack.getName().getString();
            String durability = stack.isEmpty() || !stack.isDamageable()
                    ? "--"
                    : Integer.toString(stack.getMaxDamage() - stack.getDamage());
            context.drawTextWithShadow(
                    client.textRenderer,
                    Text.literal(itemName + "  " + durability),
                    x(),
                    lineY,
                    0xFFE8E4FF
            );
            lineY += 10;
        }
    }
}
