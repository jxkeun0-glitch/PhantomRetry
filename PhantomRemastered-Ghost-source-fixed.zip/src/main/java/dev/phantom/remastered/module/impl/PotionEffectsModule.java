package dev.phantom.remastered.module.impl;

import dev.phantom.remastered.module.HudModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public final class PotionEffectsModule extends HudModule {
    public PotionEffectsModule() {
        super("potion_effects", "Potion Effects", "Lists active effects and their remaining time.", 12, 140);
    }

    @Override
    public void renderHud(MinecraftClient client, DrawContext context, RenderTickCounter tickCounter) {
        if (client.player == null) {
            return;
        }
        List<String> lines = new ArrayList<>();
        for (StatusEffectInstance effect : client.player.getStatusEffects()) {
            String name = effect.getEffectType().value().getName().getString();
            int seconds = Math.max(0, effect.getDuration() / 20);
            lines.add(name + "  " + String.format("%d:%02d", seconds / 60, seconds % 60));
        }
        if (lines.isEmpty()) {
            return;
        }
        int width = lines.stream().mapToInt(client.textRenderer::getWidth).max().orElse(48);
        context.fill(x() - 5, y() - 4, x() + width + 7, y() + 12 + lines.size() * 11, 0xB0101220);
        context.drawTextWithShadow(client.textRenderer, Text.literal("EFFECTS"), x(), y(), 0xFFBBA8FF);
        int lineY = y() + 12;
        for (String line : lines) {
            context.drawTextWithShadow(client.textRenderer, Text.literal(line), x(), lineY, 0xFFE8E4FF);
            lineY += 11;
        }
    }
}
