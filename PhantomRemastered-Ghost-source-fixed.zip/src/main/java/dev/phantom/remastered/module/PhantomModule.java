package dev.phantom.remastered.module;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.phantom.remastered.gui.GuiStyle;
import dev.phantom.remastered.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

import java.util.ArrayList;
import java.util.List;

public abstract class PhantomModule {
    private final String id;
    private final String name;
    private final String description;
    private final ModuleStatus status;
    private final List<Setting<?>> settings = new ArrayList<>();
    private boolean enabled;
    private int keybind;

    protected PhantomModule(String id, String name, String description, ModuleStatus status) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.status = status;
    }

    protected final <T extends Setting<?>> T addSetting(T setting) {
        settings.add(setting);
        return setting;
    }

    public void setEnabled(boolean enabled) {
        if (status != ModuleStatus.WORKING) {
            this.enabled = false;
            return;
        }
        if (this.enabled == enabled) {
            return;
        }
        this.enabled = enabled;
        if (enabled) {
            onEnable();
        } else {
            onDisable();
        }
    }

    protected void onEnable() {}

    protected void onDisable() {}

    public void tick(MinecraftClient client) {}

    public void renderHud(MinecraftClient client, DrawContext context, RenderTickCounter tickCounter) {}

    public JsonObject toJson() {
        JsonObject json = new JsonObject();
        json.addProperty("enabled", enabled);
        json.addProperty("keybind", keybind);
        JsonObject savedSettings = new JsonObject();
        for (Setting<?> setting : settings) {
            savedSettings.add(setting.id(), setting.toJson());
        }
        json.add("settings", savedSettings);
        return json;
    }

    public void fromJson(JsonObject json) {
        setEnabled(json.has("enabled") && json.get("enabled").getAsBoolean());
        if (json.has("keybind")) {
            keybind = json.get("keybind").getAsInt();
        }
        if (json.has("settings") && json.get("settings").isJsonObject()) {
            JsonObject savedSettings = json.getAsJsonObject("settings");
            for (Setting<?> setting : settings) {
                JsonElement value = savedSettings.get(setting.id());
                if (value != null) {
                    setting.fromJson(value);
                }
            }
        }
    }

    public void reset() {
        setEnabled(false);
        keybind = 0;
        settings.forEach(Setting::reset);
    }

    public String category(GuiStyle style) {
        return switch (style) {
            case GHOST -> defaultGhostCategory();
            case CRYSTAL_MACE -> defaultCrystalCategory();
            case RAGE -> defaultRageCategory();
        };
    }

    protected String defaultGhostCategory() {
        return "HUD";
    }

    protected String defaultCrystalCategory() {
        return "HUD";
    }

    protected String defaultRageCategory() {
        return "HUD";
    }

    public String id() {
        return id;
    }

    public String name() {
        return name;
    }

    public String description() {
        return description;
    }

    public ModuleStatus status() {
        return status;
    }

    public boolean enabled() {
        return enabled;
    }

    public int keybind() {
        return keybind;
    }

    public void setKeybind(int keybind) {
        this.keybind = keybind;
    }

    public List<Setting<?>> settings() {
        return List.copyOf(settings);
    }
}
