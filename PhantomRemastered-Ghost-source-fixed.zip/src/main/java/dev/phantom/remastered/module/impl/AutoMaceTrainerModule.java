package dev.phantom.remastered.module.impl;

import dev.phantom.remastered.module.HudModule;
import dev.phantom.remastered.setting.BooleanSetting;
import dev.phantom.remastered.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.Items;
import net.minecraft.text.Text;

/** Mace timing feedback for practice; it never aims, clicks, or attacks. */
public final class AutoMaceTrainerModule extends HudModule {
    private final NumberSetting tickWindow = addSetting(new NumberSetting("tick_window", "Timing Window (ticks)", 1, 1, 10, 1));
    private final NumberSetting fallThreshold = addSetting(new NumberSetting("fall_threshold", "Fall Threshold", 3.0, 0.5, 30.0, 0.5));
    private final BooleanSetting mainHandOnly = addSetting(new BooleanSetting("main_hand_only", "Main Hand Only", true));
    private final BooleanSetting showFallDistance = addSetting(new BooleanSetting("show_fall_distance", "Show Fall Distance", true));

    private boolean maceEquipped;
    private float fallDistance;

    public AutoMaceTrainerModule() {
        super("automace_trainer", "AutoMace Trainer", "Displays mace and fall-timing feedback; never performs attacks.", 12, 260);
    }

    @Override
    public void tick(MinecraftClient client) {
        maceEquipped = false;
        fallDistance = 0;
        if (client.player == null) return;
        boolean main = client.player.getMainHandStack().isOf(Items.MACE);
        boolean off = client.player.getOffHandStack().isOf(Items.MACE);
        maceEquipped = mainHandOnly.value() ? main : (main || off);
        fallDistance = client.player.fallDistance;
    }

    @Override
    public void renderHud(MinecraftClient client, DrawContext context, RenderTickCounter tickCounter) {
        boolean ready = maceEquipped && fallDistance >= fallThreshold.value();
        String first = "MACE TIMING  " + (ready ? "WINDOW" : "WAITING");
        String second = "Window: " + tickWindow.value().intValue() + " tick(s)";
        if (showFallDistance.value()) {
            second += String.format(java.util.Locale.ROOT, "  Fall: %.1f", fallDistance);
        }
        int width = Math.max(client.textRenderer.getWidth(first), client.textRenderer.getWidth(second));
        context.fill(x() - 5, y() - 4, x() + width + 7, y() + 27, 0xB0101220);
        context.drawTextWithShadow(client.textRenderer, Text.literal(first), x(), y(), 0xFFBBA8FF);
        context.drawTextWithShadow(client.textRenderer, Text.literal(second), x(), y() + 12, 0xFFE8E4FF);
    }

    @Override protected String defaultGhostCategory() { return "Combat"; }
    @Override protected String defaultCrystalCategory() { return "Mace Practice"; }
    @Override protected String defaultRageCategory() { return "Practice"; }
}
