package dev.phantom.remastered.module;

public enum ModuleStatus {
    WORKING,
    TESTING,
    PLANNED,
    DISABLED
}
