package dev.phantom.remastered.module.impl;

import dev.phantom.remastered.module.ModuleStatus;
import dev.phantom.remastered.module.PhantomModule;
import net.minecraft.client.MinecraftClient;

public final class ToggleSprintModule extends PhantomModule {
    public ToggleSprintModule() {
        super("toggle_sprint", "Toggle Sprint", "Keeps sprint enabled while forward movement is held when vanilla conditions allow.", ModuleStatus.WORKING);
    }

    @Override
    public void tick(MinecraftClient client) {
        if (client.player == null || client.options == null) {
            return;
        }
        if (client.options.forwardKey.isPressed()
                && !client.options.sneakKey.isPressed()
                && !client.player.isUsingItem()
                && client.player.getHungerManager().getFoodLevel() > 6) {
            client.player.setSprinting(true);
        }
    }

    @Override
    protected String defaultGhostCategory() {
        return "Movement";
    }

    @Override
    protected String defaultCrystalCategory() {
        return "Movement";
    }

    @Override
    protected String defaultRageCategory() {
        return "Movement";
    }
}
