package dev.phantom.remastered.module;

import dev.phantom.remastered.setting.NumberSetting;
import dev.phantom.remastered.setting.Setting;

public abstract class HudModule extends PhantomModule {
    private final NumberSetting x;
    private final NumberSetting y;

    protected HudModule(String id, String name, String description, int defaultX, int defaultY) {
        super(id, name, description, ModuleStatus.WORKING);
        x = addSetting(new NumberSetting("x", "HUD X", defaultX, 0, 1800, 10));
        y = addSetting(new NumberSetting("y", "HUD Y", defaultY, 0, 1000, 10));
    }

    protected int x() {
        return x.value().intValue();
    }

    protected int y() {
        return y.value().intValue();
    }

    public void resetPosition() {
        for (Setting<?> setting : settings()) {
            if (setting.id().equals("x") || setting.id().equals("y")) {
                setting.reset();
            }
        }
    }

    @Override
    protected String defaultGhostCategory() {
        return "HUD";
    }

    @Override
    protected String defaultCrystalCategory() {
        return "HUD";
    }

    @Override
    protected String defaultRageCategory() {
        return "HUD";
    }
}
