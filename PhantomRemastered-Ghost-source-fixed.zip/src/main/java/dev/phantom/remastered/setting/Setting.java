package dev.phantom.remastered.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public abstract class Setting<T> {
    private final String id;
    private final String name;
    private final T defaultValue;
    private T value;

    protected Setting(String id, String name, T defaultValue) {
        this.id = id;
        this.name = name;
        this.defaultValue = defaultValue;
        this.value = defaultValue;
    }

    public abstract void adjust(int direction);

    public abstract T parse(JsonElement json);

    public JsonElement toJson() {
        return new JsonPrimitive(value.toString());
    }

    public void fromJson(JsonElement json) {
        try {
            setValue(parse(json));
        } catch (RuntimeException ignored) {
            reset();
        }
    }

    public void reset() {
        value = defaultValue;
    }

    protected void setValue(T value) {
        this.value = value;
    }

    public String id() {
        return id;
    }

    public String name() {
        return name;
    }

    public T value() {
        return value;
    }

    public T defaultValue() {
        return defaultValue;
    }
}
