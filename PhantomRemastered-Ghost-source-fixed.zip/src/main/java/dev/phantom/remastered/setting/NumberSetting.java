package dev.phantom.remastered.setting;

import com.google.gson.JsonElement;

public final class NumberSetting extends Setting<Double> {
    private final double minimum;
    private final double maximum;
    private final double step;

    public NumberSetting(String id, String name, double defaultValue, double minimum, double maximum, double step) {
        super(id, name, defaultValue);
        this.minimum = minimum;
        this.maximum = maximum;
        this.step = step;
    }

    @Override
    public void adjust(int direction) {
        setValue(clamp(value() + step * direction));
    }

    @Override
    public Double parse(JsonElement json) {
        return clamp(json.getAsDouble());
    }

    private double clamp(double candidate) {
        return Math.max(minimum, Math.min(maximum, candidate));
    }
}
