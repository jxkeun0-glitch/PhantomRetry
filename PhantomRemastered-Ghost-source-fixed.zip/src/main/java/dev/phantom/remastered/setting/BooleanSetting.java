package dev.phantom.remastered.setting;

import com.google.gson.JsonElement;

public final class BooleanSetting extends Setting<Boolean> {
    public BooleanSetting(String id, String name, boolean defaultValue) {
        super(id, name, defaultValue);
    }

    @Override
    public void adjust(int direction) {
        setValue(!value());
    }

    @Override
    public Boolean parse(JsonElement json) {
        return json.getAsBoolean();
    }
}
