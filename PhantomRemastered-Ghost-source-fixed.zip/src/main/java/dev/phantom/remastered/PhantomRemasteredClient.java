package dev.phantom.remastered;

import dev.phantom.remastered.config.ConfigManager;
import dev.phantom.remastered.gui.PhantomScreen;
import dev.phantom.remastered.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public final class PhantomRemasteredClient implements ClientModInitializer {
    public static final String MOD_ID = "phantomremastered";
    public static ConfigManager CONFIG;
    public static ModuleManager MODULES;
    private static KeyBinding openGuiKey;

    @Override
    public void onInitializeClient() {
        MODULES = new ModuleManager();
        CONFIG = new ConfigManager(MODULES);
        CONFIG.loadActiveProfile();

        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.phantomremastered.open_gui",
                net.minecraft.client.util.InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyBinding.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(minecraft -> {
            while (openGuiKey.wasPressed()) {
                minecraft.setScreen(new PhantomScreen());
            }
            MODULES.tick(minecraft);
        });

        HudElementRegistry.attachElementAfter(
                VanillaHudElements.BOSS_BAR,
                Identifier.of(MOD_ID, "client_hud"),
                (context, tickCounter) -> MODULES.renderHud(context, tickCounter)
        );
    }
}
