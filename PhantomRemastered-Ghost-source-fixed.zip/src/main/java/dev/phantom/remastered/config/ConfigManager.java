package dev.phantom.remastered.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.phantom.remastered.gui.GuiStyle;
import dev.phantom.remastered.module.ModuleManager;
import dev.phantom.remastered.util.ColorParser;
import net.minecraft.client.MinecraftClient;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.regex.Pattern;

public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Pattern SAFE_PROFILE = Pattern.compile("[a-zA-Z0-9_-]{1,32}");
    private static final int DEFAULT_ACCENT = 0x8B5CF6;

    private final ModuleManager modules;
    private final Path root;
    private final Path profilesDirectory;
    private final Path exportsDirectory;
    private final Path activeProfileFile;
    private GuiStyle guiStyle = GuiStyle.GHOST;
    private int accentColor = DEFAULT_ACCENT;
    private String activeProfile = "default";

    public ConfigManager(ModuleManager modules) {
        this.modules = modules;
        Path gameDirectory = MinecraftClient.getInstance().runDirectory.toPath();
        this.root = gameDirectory.resolve("config").resolve("phantom-remastered");
        this.profilesDirectory = root.resolve("profiles");
        this.exportsDirectory = root.resolve("exports");
        this.activeProfileFile = root.resolve("active-profile.txt");
    }

    public void loadActiveProfile() {
        if (Files.isRegularFile(activeProfileFile)) {
            try {
                activeProfile = validateProfileName(Files.readString(activeProfileFile, StandardCharsets.UTF_8).trim());
            } catch (IOException | IllegalArgumentException ignored) {
                activeProfile = "default";
            }
        }
        loadProfile(activeProfile);
        if (!Files.exists(profilePath(activeProfile))) {
            saveProfile(activeProfile);
        }
    }

    public void saveProfile(String name) {
        String safeName = validateProfileName(name);
        try {
            Files.createDirectories(profilesDirectory);
            activeProfile = safeName;
            Files.writeString(profilePath(safeName), GSON.toJson(toJson()), StandardCharsets.UTF_8);
            Files.writeString(activeProfileFile, safeName, StandardCharsets.UTF_8);
        } catch (IOException exception) {
            throw new IllegalStateException("Could not save PhantomRemastered profile '" + safeName + "'", exception);
        }
    }

    public boolean loadProfile(String name) {
        String safeName = validateProfileName(name);
        Path path = profilePath(safeName);
        if (!Files.isRegularFile(path)) {
            return false;
        }
        try {
            JsonObject json = GSON.fromJson(Files.readString(path, StandardCharsets.UTF_8), JsonObject.class);
            if (json == null) {
                throw new IllegalArgumentException("The profile file is empty or invalid.");
            }
            readJson(json);
            activeProfile = safeName;
            return true;
        } catch (IOException exception) {
            throw new IllegalStateException("Could not read PhantomRemastered profile '" + safeName + "'", exception);
        }
    }

    public void exportProfile(String name) {
        String safeName = validateProfileName(name);
        try {
            Files.createDirectories(exportsDirectory);
            Files.writeString(exportPath(safeName), GSON.toJson(toJson()), StandardCharsets.UTF_8);
        } catch (IOException exception) {
            throw new IllegalStateException("Could not export PhantomRemastered profile '" + safeName + "'", exception);
        }
    }

    public boolean importProfile(String name) {
        String safeName = validateProfileName(name);
        Path source = exportPath(safeName);
        if (!Files.isRegularFile(source)) {
            return false;
        }
        try {
            JsonObject json = GSON.fromJson(Files.readString(source, StandardCharsets.UTF_8), JsonObject.class);
            if (json == null) {
                throw new IllegalArgumentException("The exported profile is empty or invalid.");
            }
            readJson(json);
            saveProfile(safeName);
            return true;
        } catch (IOException exception) {
            throw new IllegalStateException("Could not import PhantomRemastered profile '" + safeName + "'", exception);
        }
    }

    public JsonObject toJson() {
        JsonObject json = new JsonObject();
        json.addProperty("schemaVersion", 1);
        json.addProperty("guiStyle", guiStyle.name());
        json.addProperty("accentColor", String.format(Locale.ROOT, "#%06X", accentColor & 0xFFFFFF));
        json.add("modules", modules.toJson());
        return json;
    }

    private void readJson(JsonObject json) {
        if (json.has("guiStyle")) {
            try {
                guiStyle = GuiStyle.valueOf(json.get("guiStyle").getAsString());
            } catch (IllegalArgumentException ignored) {
                guiStyle = GuiStyle.GHOST;
            }
        }
        if (json.has("accentColor")) {
            try {
                accentColor = ColorParser.parseHex(json.get("accentColor").getAsString());
            } catch (IllegalArgumentException ignored) {
                accentColor = DEFAULT_ACCENT;
            }
        }
        JsonElement moduleData = json.get("modules");
        if (moduleData != null && moduleData.isJsonObject()) {
            modules.loadJson(moduleData.getAsJsonObject());
        }
    }

    private Path profilePath(String name) {
        return profilesDirectory.resolve(validateProfileName(name) + ".json");
    }

    private Path exportPath(String name) {
        return exportsDirectory.resolve(validateProfileName(name) + ".json");
    }

    private static String validateProfileName(String name) {
        String safeName = name == null ? "" : name.trim();
        if (!SAFE_PROFILE.matcher(safeName).matches()) {
            throw new IllegalArgumentException("Profile names may contain only letters, numbers, underscores, and hyphens (1-32 characters).");
        }
        return safeName;
    }

    public GuiStyle getGuiStyle() {
        return guiStyle;
    }

    public void setGuiStyle(GuiStyle guiStyle) {
        this.guiStyle = guiStyle;
    }

    public int getAccentColor() {
        return accentColor;
    }

    public void setAccentColor(int accentColor) {
        this.accentColor = accentColor & 0xFFFFFF;
    }

    public String getActiveProfile() {
        return activeProfile;
    }

    public void resetLayout() {
        modules.resetHudLayout();
    }
}
