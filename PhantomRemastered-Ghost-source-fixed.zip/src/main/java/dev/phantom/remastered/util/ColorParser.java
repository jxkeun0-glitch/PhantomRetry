package dev.phantom.remastered.util;

public final class ColorParser {
    private ColorParser() {}

    public static int parseHex(String input) {
        if (input == null) {
            throw new IllegalArgumentException("Color cannot be empty.");
        }
        String normalized = input.trim();
        if (normalized.startsWith("#")) {
            normalized = normalized.substring(1);
        }
        if (!normalized.matches("[0-9a-fA-F]{6}")) {
            throw new IllegalArgumentException("Enter a six-digit hexadecimal color, for example #8B5CF6.");
        }
        return Integer.parseInt(normalized, 16);
    }
}
