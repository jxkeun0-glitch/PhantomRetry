package dev.phantom.remastered.util;

public final class DurationFormat {
    private DurationFormat() {}

    public static String formatSeconds(long seconds) {
        long safeSeconds = Math.max(0, seconds);
        long hours = safeSeconds / 3600;
        long minutes = (safeSeconds % 3600) / 60;
        long remainder = safeSeconds % 60;
        if (hours > 0) {
            return String.format("%d:%02d:%02d", hours, minutes, remainder);
        }
        return String.format("%02d:%02d", minutes, remainder);
    }
}
