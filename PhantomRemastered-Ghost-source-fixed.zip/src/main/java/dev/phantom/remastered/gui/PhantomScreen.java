package dev.phantom.remastered.gui;

import dev.phantom.remastered.PhantomRemasteredClient;
import dev.phantom.remastered.module.ModuleStatus;
import dev.phantom.remastered.module.PhantomModule;
import dev.phantom.remastered.setting.Setting;
import dev.phantom.remastered.util.ColorParser;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class PhantomScreen extends Screen {
    private static final List<String> GHOST_CATEGORIES = List.of(
            "Combat", "Visuals", "Movement", "Player", "World", "HUD", "Utility", "Miscellaneous"
    );
    private static final List<String> CRYSTAL_CATEGORIES = List.of(
            "Crystal Practice", "Mace Practice", "Combat Information", "Movement", "Visuals", "HUD", "Utility"
    );
    private static final List<String> RAGE_CATEGORIES = List.of(
            "Combat Information", "Practice", "Visuals", "Movement", "Player", "HUD", "Utility"
    );

    private final List<HitTarget> hitTargets = new ArrayList<>();
    private TextFieldWidget searchField;
    private TextFieldWidget profileField;
    private TextFieldWidget colorField;
    private String selectedCategory = "HUD";
    private PhantomModule selectedModule;
    private PhantomModule awaitingBind;
    private String notice = "";
    private long noticeUntil;
    private int panelX;
    private int panelY;
    private int panelWidth;
    private int panelHeight;
    private long animationStartedAt = System.currentTimeMillis();

    public PhantomScreen() {
        super(Text.translatable("screen.phantomremastered.title"));
    }

    @Override
    protected void init() {
        int maxWidth = Math.max(300, width - 16);
        panelWidth = Math.min(1080, maxWidth);
        panelHeight = Math.max(290, Math.min(690, height - 16));
        panelX = (width - panelWidth) / 2;
        panelY = (height - panelHeight) / 2;

        searchField = new TextFieldWidget(
                textRenderer,
                panelX + Math.min(190, panelWidth / 3),
                panelY + 35,
                Math.max(100, Math.min(220, panelWidth / 3)),
                20,
                Text.literal("Search")
        );
        searchField.setMaxLength(48);
        searchField.setPlaceholder(Text.literal("Filter modules"));
        addDrawableChild(searchField);

        int inputWidth = Math.min(102, Math.max(72, (panelWidth - 140) / 2));
        profileField = new TextFieldWidget(
                textRenderer, panelX + 16, panelY + panelHeight - 52, inputWidth, 20, Text.literal("Profile")
        );
        profileField.setMaxLength(32);
        profileField.setPlaceholder(Text.literal("profile name"));
        profileField.setText(PhantomRemasteredClient.CONFIG.getActiveProfile());
        addDrawableChild(profileField);

        colorField = new TextFieldWidget(
                textRenderer, panelX + 16, panelY + panelHeight - 25, inputWidth, 20, Text.literal("Accent")
        );
        colorField.setMaxLength(7);
        colorField.setPlaceholder(Text.literal("#8B5CF6"));
        colorField.setText(String.format(Locale.ROOT, "#%06X", PhantomRemasteredClient.CONFIG.getAccentColor()));
        addDrawableChild(colorField);
        ensureCategoryExists();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        hitTargets.clear();
        context.fill(0, 0, width, height, 0xB6000000);

        switch (PhantomRemasteredClient.CONFIG.getGuiStyle()) {
            case GHOST -> renderGhost(context, mouseX, mouseY);
            case CRYSTAL_MACE -> renderCrystal(context, mouseX, mouseY);
            case RAGE -> renderRage(context, mouseX, mouseY);
        }

        super.render(context, mouseX, mouseY, delta);
        float openProgress = Math.min(1.0f, (System.currentTimeMillis() - animationStartedAt) / 240.0f);
        if (openProgress < 1.0f) {
            int fadeAlpha = Math.max(0, (int) ((1.0f - openProgress) * 118));
            context.fill(0, 0, width, height, fadeAlpha << 24);
        }
        if (!notice.isEmpty() && System.currentTimeMillis() < noticeUntil) {
            context.drawCenteredTextWithShadow(textRenderer, Text.literal(notice), width / 2, panelY + panelHeight - 76, 0xFFFFFFFF);
        }
        if (awaitingBind != null) {
            context.drawCenteredTextWithShadow(
                    textRenderer,
                    Text.literal("Press a key to bind " + awaitingBind.name() + " (Esc clears)"),
                    width / 2,
                    panelY + 15,
                    0xFFFFFFFF
            );
        }
    }

    private void renderGhost(DrawContext context, int mouseX, int mouseY) {
        if (panelWidth < 760) {
            renderStacked(context, GuiStyle.GHOST);
            return;
        }
        drawGhostBackdrop(context);
        drawGhostHeader(context, "PHANTOM / GHOST", "CLIENT HUD  ·  CONFIGURATION");
        int contentTop = panelY + 72;
        drawVerticalCategories(context, ghostCategories(), panelX + 18, contentTop, 142, mouseX, mouseY);
        drawModuleList(context, panelX + 176, contentTop, Math.max(220, panelWidth - 472), panelHeight - 144, mouseX, mouseY);
        drawSettingsCard(context, panelX + panelWidth - 276, contentTop, 254, panelHeight - 144, mouseX, mouseY);
        drawFooter(context, mouseX, mouseY, true);
    }

    private void renderCrystal(DrawContext context, int mouseX, int mouseY) {
        if (panelWidth < 760) {
            renderStacked(context, GuiStyle.CRYSTAL_MACE);
            return;
        }
        int x = panelX + 10;
        int y = panelY + 7;
        int w = panelWidth - 20;
        int h = panelHeight - 14;
        context.fill(x + 3, y + 5, x + w + 3, y + h + 5, 0x90000000);
        context.fill(x, y, x + w, y + h, 0xFF110B0D);
        context.fill(x, y, x + w, y + 2, 0xFFE33B4B);
        context.fill(x, y + 2, x + w, y + 3, 0xFF79202A);
        drawText(context, "CRYSTAL / MACE", x + 20, y + 17, 0xFFFFE8EA);
        drawText(context, "PRACTICE LOADOUT     ·     INFORMATION ONLY", x + 20, y + 33, 0xFFAF7C82);
        drawCrystalStats(context, x + w - 238, y + 17);

        int categoryY = y + 62;
        drawHorizontalCategories(context, crystalCategories(), x + 18, categoryY, w - 36, 2, mouseX, mouseY);
        int contentTop = y + 118;
        int leftWidth = Math.max(210, (w - 56) * 57 / 100);
        drawModuleGrid(context, x + 18, contentTop, leftWidth, h - 196, mouseX, mouseY);
        drawSettingsCard(context, x + 32 + leftWidth, contentTop, w - leftWidth - 50, h - 196, mouseX, mouseY);
        drawAdaptiveFooter(context, panelX, panelY, panelWidth, panelHeight, true);
    }

    private void renderRage(DrawContext context, int mouseX, int mouseY) {
        if (panelWidth < 760) {
            renderStacked(context, GuiStyle.RAGE);
            return;
        }
        int x = panelX + 4;
        int y = panelY + 4;
        int w = panelWidth - 8;
        int h = panelHeight - 8;
        context.fill(0, 0, width, height, 0xE4000000);
        context.fill(x, y, x + w, y + h, 0xFF080809);
        context.fill(x, y, x + w, y + 4, 0xFFFF2638);
        context.fill(x + 14, y + 14, x + 17, y + h - 14, 0xFF9A1420);
        context.fill(x + 14, y + h - 70, x + w - 14, y + h - 67, 0xFF3A1014);
        drawText(context, "PHANTOM", x + 32, y + 19, 0xFFFFF1F2);
        drawText(context, "RAGE INTERFACE  /  PRACTICE TELEMETRY", x + 32, y + 39, 0xFFD14D59);
        drawText(context, "03  INTERFACES", x + w - 150, y + 21, 0xFF8D7779);

        int navX = x + 28;
        int navY = y + 76;
        drawAngularCategories(context, rageCategories(), navX, navY, 142, mouseX, mouseY);
        int centerX = x + 190;
        int rightX = x + w - 286;
        int top = y + 76;
        int centerWidth = Math.max(200, rightX - centerX - 18);
        context.fill(centerX - 10, top - 8, rightX - 14, y + h - 84, 0xFF101012);
        context.fill(centerX - 10, top - 8, centerX - 6, y + h - 84, 0xFFEB2333);
        drawText(context, "MODULE INDEX", centerX + 8, top, 0xFFF7EDEF);
        drawModuleList(context, centerX + 8, top + 24, centerWidth - 26, h - 190, mouseX, mouseY);
        drawRageStatus(context, rightX, top, x + w - 24, y + h - 84, mouseX, mouseY);
        drawAdaptiveFooter(context, panelX, panelY, panelWidth, panelHeight, true);
        drawRageGlitchLines(context, x, y, w);
    }

    private void renderStacked(DrawContext context, GuiStyle style) {
        int x = panelX;
        int y = panelY;
        int w = panelWidth;
        int h = panelHeight;
        int topAccent = switch (style) {
            case GHOST -> 0xFF8055EA;
            case CRYSTAL_MACE -> 0xFFE33B4B;
            case RAGE -> 0xFFFF2638;
        };
        int panelFill = style == GuiStyle.GHOST ? 0xFF11121A : 0xFF100B0D;
        contextPanel(context, style, x, y, w, h, panelFill, topAccent);
        drawTextForStyle(context, style, style == GuiStyle.GHOST ? "PHANTOM / GHOST"
                : style == GuiStyle.CRYSTAL_MACE ? "CRYSTAL / MACE PRACTICE" : "PHANTOM / RAGE",
                x + 16, y + 13, 0xFFF7F0F3);
        drawTextForStyle(context, style, "RIGHT SHIFT  /  CLOSE", x + w - 145, y + 17, 0xFFAA9298);

        drawResponsiveCategories(context, currentCategories(), x + 14, y + 61, w - 28);
        int contentTop = y + 166;
        int footerStart = y + h - 78;
        int available = Math.max(230, footerStart - contentTop - 5);
        int moduleHeight = Math.max(130, Math.min(available - 195, available * 45 / 100));
        int settingsHeight = available - moduleHeight - 5;
        drawCompactModuleList(context, x + 14, contentTop, w - 28, moduleHeight);
        drawSettingsCard(context, x + 14, contentTop + moduleHeight + 5, w - 28, settingsHeight, 0, 0);
        drawAdaptiveFooter(context, x, y, w, h, style != GuiStyle.GHOST);
    }

    private void contextPanel(DrawContext context, GuiStyle style, int x, int y, int w, int h, int fill, int accent) {
        if (style == GuiStyle.RAGE) {
            context.fill(0, 0, width, height, 0xE4000000);
            context.fill(x, y, x + w, y + h, fill);
            context.fill(x, y, x + w, y + 4, accent);
            context.fill(x + 12, y + 12, x + 15, y + h - 12, 0xFF9A1420);
            context.fill(x + 15, y + 55, x + w - 12, y + 56, 0xFF331217);
        } else {
            context.fill(x + 5, y + 6, x + w + 5, y + h + 6, 0x75000000);
            context.fill(x, y, x + w, y + h, fill);
            context.fill(x, y, x + w, y + 3, accent);
            context.fill(x, y + 3, x + w, y + 4, style == GuiStyle.GHOST ? 0xFF44306F : 0xFF79202A);
        }
    }

    private void drawTextForStyle(DrawContext context, GuiStyle style, String text, int x, int y, int color) {
        drawText(context, text, x, y, color);
    }

    private void drawGhostBackdrop(DrawContext context) {
        int x = panelX;
        int y = panelY;
        int w = panelWidth;
        int h = panelHeight;
        context.fill(x + 8, y + 9, x + w + 8, y + h + 9, 0x70000000);
        context.fill(x, y, x + w, y + h, 0xFF11121A);
        context.fill(x, y, x + w, y + 48, 0xFF171825);
        context.fill(x, y, x + 3, y + h, 0xFF8055EA);
        context.fill(x + 3, y, x + w, y + 1, 0xFF44306F);
        context.fill(x + 16, y + 61, x + w - 16, y + 62, 0xFF2A2939);
    }

    private void drawGhostHeader(DrawContext context, String titleText, String subtitle) {
        drawText(context, titleText, panelX + 21, panelY + 13, 0xFFF5F1FF);
        drawText(context, subtitle, panelX + 21, panelY + 29, 0xFF8D879E);
        drawText(context, "RIGHT SHIFT  /  CLOSE", panelX + panelWidth - 170, panelY + 18, 0xFFB3A7D1);
        drawText(context, "SEARCH", searchField.getX() - 43, searchField.getY() + 6, 0xFF777486);
    }

    private void drawVerticalCategories(
            DrawContext context, List<String> categories, int x, int y, int w, int mouseX, int mouseY
    ) {
        drawText(context, "CATEGORIES", x, y, 0xFF817D91);
        int rowY = y + 20;
        for (String category : categories) {
            boolean active = selectedCategory.equals(category);
            int h = 27;
            context.fill(x, rowY, x + w, rowY + h, active ? 0xFF282236 : 0xFF171820);
            if (active) {
                context.fill(x, rowY, x + 3, rowY + h, PhantomRemasteredClient.CONFIG.getAccentColor() | 0xFF000000);
            }
            drawText(context, category, x + 11, rowY + 8, active ? 0xFFE9DEFF : 0xFF9693A2);
            addTarget(x, rowY, w, h, () -> selectedCategory = category);
            rowY += 31;
        }
    }

    private void drawAngularCategories(
            DrawContext context, List<String> categories, int x, int y, int w, int mouseX, int mouseY
    ) {
        drawText(context, "SECTIONS", x, y, 0xFF8E8284);
        int rowY = y + 23;
        for (int i = 0; i < categories.size(); i++) {
            String category = categories.get(i);
            boolean active = selectedCategory.equals(category);
            int h = 29;
            int fill = active ? 0xFF341216 : 0xFF141315;
            context.fill(x, rowY, x + w, rowY + h, fill);
            context.fill(x, rowY, x + 3, rowY + h, active ? 0xFFFF3040 : 0xFF3B2023);
            drawText(context, String.format("%02d", i + 1), x + 10, rowY + 9, 0xFFCE4B55);
            drawText(context, category, x + 37, rowY + 9, active ? 0xFFFFEDEF : 0xFF95898B);
            addTarget(x, rowY, w, h, () -> selectedCategory = category);
            rowY += 33;
        }
    }

    private void drawHorizontalCategories(
            DrawContext context, List<String> categories, int x, int y, int width, int rows, int mouseX, int mouseY
    ) {
        int columns = Math.min(4, categories.size());
        int gap = 6;
        int buttonWidth = (width - (columns - 1) * gap) / columns;
        for (int index = 0; index < categories.size(); index++) {
            String category = categories.get(index);
            int row = index / columns;
            int column = index % columns;
            int bx = x + column * (buttonWidth + gap);
            int by = y + row * 26;
            boolean active = selectedCategory.equals(category);
            context.fill(bx, by, bx + buttonWidth, by + 22, active ? 0xFF501A21 : 0xFF211316);
            context.fill(bx, by, bx + buttonWidth, by + 1, active ? 0xFFEF4654 : 0xFF482026);
            drawCentered(context, category, bx + buttonWidth / 2, by + 7, active ? 0xFFFFE7E9 : 0xFFB18A8E);
            addTarget(bx, by, buttonWidth, 22, () -> selectedCategory = category);
        }
    }

    private void drawResponsiveCategories(DrawContext context, List<String> categories, int x, int y, int width) {
        int columns = 2;
        int gap = 6;
        int buttonWidth = (width - gap) / columns;
        boolean rage = PhantomRemasteredClient.CONFIG.getGuiStyle() == GuiStyle.RAGE;
        for (int index = 0; index < categories.size(); index++) {
            String category = categories.get(index);
            int bx = x + (index % columns) * (buttonWidth + gap);
            int by = y + (index / columns) * 24;
            boolean active = selectedCategory.equals(category);
            int base = rage ? 0xFF181012 : 0xFF211316;
            int selected = rage ? 0xFF42151B : 0xFF501A21;
            context.fill(bx, by, bx + buttonWidth, by + 21, active ? selected : base);
            context.fill(bx, by, bx + 3, by + 21, active
                    ? (rage ? 0xFFFF2638 : 0xFFEF4654)
                    : (rage ? 0xFF57232A : 0xFF482026));
            drawText(context, category, bx + 10, by + 7, active ? 0xFFFFE7E9 : 0xFFB18A8E);
            addTarget(bx, by, buttonWidth, 21, () -> selectedCategory = category);
        }
    }

    private void drawCompactModuleList(DrawContext context, int x, int y, int width, int height) {
        drawText(context, "MODULES  /  " + selectedCategory.toUpperCase(Locale.ROOT), x, y, 0xFF9D8C90);
        List<PhantomModule> filtered = filteredModules();
        if (filtered.isEmpty()) {
            drawText(context, "No working modules in this category.", x + 4, y + 35, 0xFF947D80);
            return;
        }
        int rowY = y + 19;
        int rowHeight = 29;
        int maxRows = Math.max(1, Math.min(filtered.size(), (height - 20) / rowHeight));
        for (int i = 0; i < maxRows; i++) {
            PhantomModule module = filtered.get(i);
            boolean active = module.enabled();
            int fill = selectedModule == module ? 0xFF332126 : (active ? 0xFF281B1E : 0xFF191416);
            context.fill(x, rowY, x + width, rowY + rowHeight - 2, fill);
            if (selectedModule == module) {
                context.fill(x, rowY, x + 2, rowY + rowHeight - 2, 0xFFFF4654);
            }
            drawText(context, module.name(), x + 9, rowY + 4, 0xFFFFE9EB);
            drawText(context, module.status().name(), x + 9, rowY + 16, statusColor(module.status()));
            int toggleX = x + width - 38;
            context.fill(toggleX, rowY + 6, x + width - 8, rowY + 22,
                    active ? 0xFFAD2734 : 0xFF44373A);
            context.fill(active ? x + width - 21 : toggleX + 2, rowY + 8,
                    active ? x + width - 10 : toggleX + 15, rowY + 20, 0xFFF8ECEE);
            addTarget(x, rowY, width, rowHeight - 2, () -> selectedModule = module);
            addTarget(toggleX - 2, rowY + 2, 34, rowHeight - 4, () -> {
                selectedModule = module;
                module.setEnabled(!module.enabled());
                saveCurrentProfile();
            });
            rowY += rowHeight;
        }
    }

    private void drawModuleList(
            DrawContext context, int x, int y, int width, int height, int mouseX, int mouseY
    ) {
        drawText(context, "MODULES  /  " + selectedCategory.toUpperCase(Locale.ROOT), x, y, 0xFF888496);
        List<PhantomModule> filtered = filteredModules();
        if (filtered.isEmpty()) {
            drawText(context, "No active modules in this category.", x + 4, y + 39, 0xFF777482);
            drawText(context, "Unimplemented features are not shown as working.", x + 4, y + 56, 0xFF5F5D6A);
            return;
        }
        int rowY = y + 22;
        int rowHeight = 47;
        int maxRows = Math.max(1, Math.min(filtered.size(), (height - 28) / rowHeight));
        for (int i = 0; i < maxRows; i++) {
            PhantomModule module = filtered.get(i);
            boolean selected = selectedModule == module;
            int rowColor = selected ? 0xFF252330 : (module.enabled() ? 0xFF1E2028 : 0xFF181920);
            context.fill(x, rowY, x + width, rowY + rowHeight - 4, rowColor);
            if (selected) {
                context.fill(x, rowY, x + 2, rowY + rowHeight - 4, PhantomRemasteredClient.CONFIG.getAccentColor() | 0xFF000000);
            }
            drawText(context, module.name(), x + 10, rowY + 7, 0xFFF0EDF7);
            drawText(context, module.description(), x + 10, rowY + 22, 0xFF858390);
            drawText(context, module.status().name(), x + 10, rowY + 34, statusColor(module.status()));
            int toggleX = x + width - 47;
            int toggleColor = module.enabled() ? PhantomRemasteredClient.CONFIG.getAccentColor() | 0xFF000000 : 0xFF3B3A43;
            context.fill(toggleX, rowY + 13, x + width - 9, rowY + 31, toggleColor);
            context.fill(module.enabled() ? x + width - 24 : toggleX + 2, rowY + 15,
                    module.enabled() ? x + width - 11 : toggleX + 18, rowY + 29, 0xFFF5F2FA);
            addTarget(x, rowY, width, rowHeight - 4, () -> selectedModule = module);
            addTarget(toggleX - 2, rowY + 5, 42, 29, () -> {
                selectedModule = module;
                module.setEnabled(!module.enabled());
                saveCurrentProfile();
            });
            rowY += rowHeight;
        }
    }

    private void drawModuleGrid(
            DrawContext context, int x, int y, int width, int height, int mouseX, int mouseY
    ) {
        drawText(context, "PRACTICE MODULES", x, y, 0xFFAB747A);
        List<PhantomModule> filtered = filteredModules();
        if (filtered.isEmpty()) {
            drawText(context, "No working modules in this category.", x + 4, y + 40, 0xFF947D80);
            return;
        }
        int gap = 9;
        int cardWidth = (width - gap) / 2;
        int cardHeight = 62;
        int startY = y + 22;
        int cards = Math.min(filtered.size(), Math.max(1, (height - 28) / (cardHeight + gap)) * 2);
        for (int i = 0; i < cards; i++) {
            PhantomModule module = filtered.get(i);
            int column = i % 2;
            int row = i / 2;
            int bx = x + column * (cardWidth + gap);
            int by = startY + row * (cardHeight + gap);
            boolean active = module.enabled();
            context.fill(bx, by, bx + cardWidth, by + cardHeight, active ? 0xFF32171D : 0xFF211619);
            context.fill(bx, by, bx + cardWidth, by + 2, active ? 0xFFE44250 : 0xFF52272D);
            drawText(context, module.name(), bx + 9, by + 9, 0xFFFFE9EB);
            drawText(context, module.status().name(), bx + 9, by + 24, statusColor(module.status()));
            drawText(context, active ? "ACTIVE" : "CLICK TO SELECT", bx + 9, by + 42, 0xFFC4878D);
            addTarget(bx, by, cardWidth, cardHeight, () -> {
                selectedModule = module;
                module.setEnabled(!module.enabled());
            });
        }
    }

    private void drawSettingsCard(
            DrawContext context, int x, int y, int width, int height, int mouseX, int mouseY
    ) {
        context.fill(x, y, x + width, y + height, PhantomRemasteredClient.CONFIG.getGuiStyle() == GuiStyle.CRYSTAL_MACE
                ? 0xFF1B1113 : 0xFF171820);
        String titleColor = PhantomRemasteredClient.CONFIG.getGuiStyle() == GuiStyle.CRYSTAL_MACE
                ? "0xFFFF9BA2" : "0xFFBBA8FF";
        drawText(context, "MODULE SETTINGS", x + 13, y + 12, parseColorLiteral(titleColor));
        if (selectedModule == null || !selectedModule.category(PhantomRemasteredClient.CONFIG.getGuiStyle()).equals(selectedCategory)) {
            drawText(context, "Select a module to", x + 13, y + 44, 0xFF8A8795);
            drawText(context, "view its controls.", x + 13, y + 59, 0xFF8A8795);
            drawText(context, "Settings persist in profiles.", x + 13, y + 91, 0xFF686674);
            return;
        }

        drawText(context, selectedModule.name(), x + 13, y + 39, 0xFFF2EEF8);
        drawText(context, selectedModule.status().name(), x + 13, y + 56, statusColor(selectedModule.status()));
        drawText(context, selectedModule.description(), x + 13, y + 77, 0xFF9895A2);
        int rowY = y + 106;
        int rowIndex = 0;
        for (Setting<?> setting : selectedModule.settings()) {
            int currentY = rowY + rowIndex * 25;
            drawText(context, setting.name(), x + 13, currentY, 0xFFD6D2DE);
            drawText(context, "‹", x + width - 55, currentY, 0xFFB7A5E8);
            drawText(context, valueText(setting), x + width - 43, currentY, 0xFFFFFFFF);
            drawText(context, "›", x + width - 13, currentY, 0xFFB7A5E8);
            addTarget(x + width - 61, currentY - 4, 16, 20, () -> {
                setting.adjust(-1);
                saveCurrentProfile();
            });
            addTarget(x + width - 17, currentY - 4, 16, 20, () -> {
                setting.adjust(1);
                saveCurrentProfile();
            });
            rowIndex++;
        }

        int bindY = rowY + rowIndex * 25 + 3;
        drawText(context, "Keybind", x + 13, bindY, 0xFFD6D2DE);
        drawText(context, selectedModule.keybind() == 0 ? "Set key" : keyName(selectedModule.keybind()),
                x + width - 72, bindY, 0xFFFFD0D3);
        addTarget(x + width - 88, bindY - 4, 81, 20, () -> awaitingBind = selectedModule);

        int resetY = y + height - 35;
        drawButton(context, "RESET MODULE", x + 12, resetY, Math.min(116, width - 24), 23, 0xFF35212A, 0xFFFFB4BB);
        addTarget(x + 12, resetY, Math.min(116, width - 24), 23, () -> {
            selectedModule.reset();
            saveCurrentProfile();
        });
    }

    private void drawRageStatus(
            DrawContext context, int x, int y, int right, int bottom, int mouseX, int mouseY
    ) {
        context.fill(x, y, right, bottom, 0xFF151113);
        context.fill(x, y, x + 2, bottom, 0xFFB81F2C);
        drawText(context, "LIVE PROFILE", x + 14, y + 10, 0xFFE7D7D9);
        drawText(context, PhantomRemasteredClient.CONFIG.getActiveProfile().toUpperCase(Locale.ROOT), x + 14, y + 32, 0xFFFF4653);
        drawText(context, "STYLE", x + 14, y + 69, 0xFF806F72);
        drawText(context, PhantomRemasteredClient.CONFIG.getGuiStyle().label().toUpperCase(Locale.ROOT), x + 14, y + 87, 0xFFF6E5E7);
        drawText(context, "ACCENT", x + 14, y + 120, 0xFF806F72);
        int color = PhantomRemasteredClient.CONFIG.getAccentColor();
        context.fill(x + 14, y + 139, x + 52, y + 157, 0xFF000000 | color);
        drawText(context, String.format("#%06X", color), x + 61, y + 144, 0xFFE7D7D9);
        drawText(context, "ENABLED", x + 14, y + 193, 0xFF806F72);
        long enabled = PhantomRemasteredClient.MODULES.all().stream().filter(PhantomModule::enabled).count();
        drawText(context, String.format("%02d  /  %02d", enabled, PhantomRemasteredClient.MODULES.all().size()),
                x + 14, y + 211, 0xFFFF4653);
        if (selectedModule != null) {
            drawText(context, "SELECTED", x + 14, y + 254, 0xFF806F72);
            drawText(context, selectedModule.name().toUpperCase(Locale.ROOT), x + 14, y + 272, 0xFFF6E5E7);
        }
        drawText(context, "NO HIDDEN ENTITY DATA", x + 14, bottom - 24, 0xFF8A6266);
    }

    private void drawCrystalStats(DrawContext context, int x, int y) {
        drawText(context, "SESSION", x, y, 0xFF956D72);
        long enabled = PhantomRemasteredClient.MODULES.all().stream().filter(PhantomModule::enabled).count();
        drawText(context, String.format("%02d ACTIVE  /  %02d MODULES", enabled, PhantomRemasteredClient.MODULES.all().size()),
                x, y + 16, 0xFFFFBFC3);
    }

    private void drawRageGlitchLines(DrawContext context, int x, int y, int width) {
        long phase = System.currentTimeMillis() / 90;
        int stripeY = y + 58 + (int) (phase % 5) - 2;
        int shift = (int) (phase % 9) - 4;
        context.fill(x + width - 172 + shift, stripeY, x + width - 120 + shift, stripeY + 2, 0xAAFF2638);
        context.fill(x + width - 112 - shift, stripeY + 3, x + width - 82 - shift, stripeY + 4, 0xAAFF2638);
        context.fill(x + 18 + shift, y + 51, x + 94 + shift, y + 52, 0x884E1920);
    }

    private void drawFooter(DrawContext context, int mouseX, int mouseY, boolean ghost) {
        drawAdaptiveFooter(context, panelX, panelY, panelWidth, panelHeight, !ghost);
    }

    private void drawAdaptiveFooter(DrawContext context, int x, int y, int w, int h, boolean redTheme) {
        int textColor = redTheme ? 0xFFAA777C : 0xFF817D91;
        int buttonBackground = redTheme ? 0xFF3B1D22 : 0xFF272432;
        int buttonText = redTheme ? 0xFFFFE9EB : 0xFFEAE3FC;
        int rowOneY = y + h - 52;
        int rowTwoY = y + h - 25;
        int actionX = profileField.getX() + profileField.getWidth() + 8;
        int actionGap = 3;
        int actionWidth = Math.max(28, (x + w - 16 - actionX - actionGap * 3) / 4);
        String[] labels = actionWidth < 48
                ? new String[]{"SAVE", "LOAD", "EXP", "IMP"}
                : new String[]{"SAVE", "LOAD", "EXPORT", "IMPORT"};
        Runnable[] actions = {this::saveProfile, this::loadProfile, this::exportProfile, this::importProfile};

        drawText(context, "PROFILE", x + 16, rowOneY - 11, textColor);
        drawText(context, "ACCENT", x + 16, rowTwoY - 10, textColor);
        context.fill(x + 14, rowOneY - 4, x + w - 14, rowOneY - 3, redTheme ? 0xFF3A1B20 : 0xFF2A2939);
        for (int i = 0; i < labels.length; i++) {
            int bx = actionX + i * (actionWidth + actionGap);
            drawButton(context, labels[i], bx, rowOneY, actionWidth, 20, buttonBackground, buttonText);
            addTarget(bx, rowOneY, actionWidth, 20, actions[i]);
        }

        int applyX = colorField.getX() + colorField.getWidth() + 8;
        int applyWidth = 48;
        drawButton(context, "APPLY", applyX, rowTwoY, applyWidth, 20, buttonBackground, buttonText);
        addTarget(applyX, rowTwoY, applyWidth, 20, this::applyAccent);

        int guiWidth = Math.min(105, Math.max(36, w - 280));
        int guiX = x + w - 16 - guiWidth;
        int resetX = applyX + applyWidth + 6;
        int resetWidth = Math.min(86, Math.max(42, guiX - resetX - 6));
        drawButton(context, "RESET HUD", resetX, rowTwoY, resetWidth, 20, buttonBackground, buttonText);
        addTarget(resetX, rowTwoY, resetWidth, 20, this::resetHud);
        String guiLabel = guiWidth < 72 ? "GUI" : "CHANGE GUI";
        drawButton(context, guiLabel, guiX, rowTwoY, guiWidth, 20, redTheme ? 0xFF541B24 : 0xFF3B2D5B, buttonText);
        addTarget(guiX, rowTwoY, guiWidth, 20, this::changeStyle);
    }

    private List<PhantomModule> filteredModules() {
        String query = searchField == null ? "" : searchField.getText().trim().toLowerCase(Locale.ROOT);
        return PhantomRemasteredClient.MODULES.inCategory(
                        PhantomRemasteredClient.CONFIG.getGuiStyle(), selectedCategory
                ).stream()
                .filter(module -> query.isEmpty()
                        || module.name().toLowerCase(Locale.ROOT).contains(query)
                        || module.description().toLowerCase(Locale.ROOT).contains(query))
                .toList();
    }

    private void ensureCategoryExists() {
        List<String> categories = currentCategories();
        if (!categories.contains(selectedCategory)) {
            selectedCategory = categories.get(0);
        }
    }

    private List<String> currentCategories() {
        return switch (PhantomRemasteredClient.CONFIG.getGuiStyle()) {
            case GHOST -> ghostCategories();
            case CRYSTAL_MACE -> crystalCategories();
            case RAGE -> rageCategories();
        };
    }

    private List<String> ghostCategories() {
        return GHOST_CATEGORIES;
    }

    private List<String> crystalCategories() {
        return CRYSTAL_CATEGORIES;
    }

    private List<String> rageCategories() {
        return RAGE_CATEGORIES;
    }

    private void addTarget(int x, int y, int w, int h, Runnable action) {
        hitTargets.add(new HitTarget(x, y, w, h, action));
    }

    private void drawButton(DrawContext context, String label, int x, int y, int w, int h, int background, int foreground) {
        context.fill(x, y, x + w, y + h, background);
        drawCentered(context, label, x + w / 2, y + (h - 8) / 2, foreground);
    }

    private void drawText(DrawContext context, String text, int x, int y, int color) {
        context.drawTextWithShadow(textRenderer, Text.literal(text), x, y, color);
    }

    private void drawCentered(DrawContext context, String text, int centerX, int y, int color) {
        context.drawCenteredTextWithShadow(textRenderer, Text.literal(text), centerX, y, color);
    }

    private int statusColor(ModuleStatus status) {
        return switch (status) {
            case WORKING -> 0xFF70D6A1;
            case TESTING -> 0xFFFFD36E;
            case PLANNED -> 0xFF9B9AA7;
            case DISABLED -> 0xFFFF7C84;
        };
    }

    private String valueText(Setting<?> setting) {
        Object value = setting.value();
        if (value instanceof Double number) {
            return String.format(Locale.ROOT, "%.0f", number);
        }
        if (value instanceof Boolean bool) {
            return bool ? "ON" : "OFF";
        }
        return String.valueOf(value);
    }

    private String keyName(int key) {
        return switch (key) {
            case GLFW.GLFW_KEY_SPACE -> "SPACE";
            case GLFW.GLFW_KEY_LEFT_SHIFT -> "L-SHIFT";
            case GLFW.GLFW_KEY_RIGHT_SHIFT -> "R-SHIFT";
            case GLFW.GLFW_KEY_LEFT_CONTROL -> "L-CTRL";
            case GLFW.GLFW_KEY_RIGHT_CONTROL -> "R-CTRL";
            default -> "KEY " + key;
        };
    }

    private int parseColorLiteral(String value) {
        return (int) Long.decode(value).longValue();
    }

    private void saveProfile() {
        try {
            PhantomRemasteredClient.CONFIG.saveProfile(profileField.getText());
            showNotice("Profile saved.");
        } catch (RuntimeException exception) {
            showNotice(exception.getMessage());
        }
    }

    private void loadProfile() {
        try {
            boolean loaded = PhantomRemasteredClient.CONFIG.loadProfile(profileField.getText());
            showNotice(loaded ? "Profile loaded." : "No profile with that name exists.");
            if (loaded) {
                profileField.setText(PhantomRemasteredClient.CONFIG.getActiveProfile());
                colorField.setText(String.format(Locale.ROOT, "#%06X", PhantomRemasteredClient.CONFIG.getAccentColor()));
                ensureCategoryExists();
            }
        } catch (RuntimeException exception) {
            showNotice(exception.getMessage());
        }
    }

    private void exportProfile() {
        try {
            PhantomRemasteredClient.CONFIG.exportProfile(profileField.getText());
            showNotice("Profile exported to the exports folder.");
        } catch (RuntimeException exception) {
            showNotice(exception.getMessage());
        }
    }

    private void importProfile() {
        try {
            boolean imported = PhantomRemasteredClient.CONFIG.importProfile(profileField.getText());
            showNotice(imported ? "Profile imported and loaded." : "No matching export exists.");
            if (imported) {
                profileField.setText(PhantomRemasteredClient.CONFIG.getActiveProfile());
                colorField.setText(String.format(Locale.ROOT, "#%06X", PhantomRemasteredClient.CONFIG.getAccentColor()));
                ensureCategoryExists();
            }
        } catch (RuntimeException exception) {
            showNotice(exception.getMessage());
        }
    }

    private void applyAccent() {
        try {
            int color = ColorParser.parseHex(colorField.getText());
            PhantomRemasteredClient.CONFIG.setAccentColor(color);
            PhantomRemasteredClient.CONFIG.saveProfile(PhantomRemasteredClient.CONFIG.getActiveProfile());
            showNotice("Accent color applied.");
        } catch (RuntimeException exception) {
            showNotice(exception.getMessage());
        }
    }

    private void resetHud() {
        PhantomRemasteredClient.CONFIG.resetLayout();
        PhantomRemasteredClient.CONFIG.saveProfile(PhantomRemasteredClient.CONFIG.getActiveProfile());
        showNotice("HUD positions reset.");
    }

    private void changeStyle() {
        PhantomRemasteredClient.CONFIG.setGuiStyle(PhantomRemasteredClient.CONFIG.getGuiStyle().next());
        animationStartedAt = System.currentTimeMillis();
        ensureCategoryExists();
        PhantomRemasteredClient.CONFIG.saveProfile(PhantomRemasteredClient.CONFIG.getActiveProfile());
        clearAndInit();
    }

    private void showNotice(String message) {
        notice = message == null ? "Operation failed." : message;
        noticeUntil = System.currentTimeMillis() + 2600;
    }

    private void saveCurrentProfile() {
        PhantomRemasteredClient.CONFIG.saveProfile(PhantomRemasteredClient.CONFIG.getActiveProfile());
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubleClick) {
        if (click.button() == 0) {
            for (int i = hitTargets.size() - 1; i >= 0; i--) {
                HitTarget target = hitTargets.get(i);
                if (target.contains(click.x(), click.y())) {
                    target.action().run();
                    return true;
                }
            }
        }
        return super.mouseClicked(click, doubleClick);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (awaitingBind != null) {
            int keyCode = input.getKeycode();
            awaitingBind.setKeybind(keyCode == GLFW.GLFW_KEY_ESCAPE ? 0 : keyCode);
            awaitingBind = null;
            PhantomRemasteredClient.CONFIG.saveProfile(PhantomRemasteredClient.CONFIG.getActiveProfile());
            return true;
        }
        if (input.getKeycode() == GLFW.GLFW_KEY_ESCAPE) {
            close();
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private record HitTarget(int x, int y, int width, int height, Runnable action) {
        boolean contains(double mouseX, double mouseY) {
            return mouseX >= x && mouseY >= y && mouseX < x + width && mouseY < y + height;
        }
    }
}
