package dev.phantom.remastered.gui;

public enum GuiStyle {
    GHOST("Ghost"),
    CRYSTAL_MACE("Crystal / Mace"),
    RAGE("Rage");

    private final String label;

    GuiStyle(String label) {
        this.label = label;
    }

    public String label() {
        return label;
    }

    public GuiStyle next() {
        GuiStyle[] styles = values();
        return styles[(ordinal() + 1) % styles.length];
    }
}
