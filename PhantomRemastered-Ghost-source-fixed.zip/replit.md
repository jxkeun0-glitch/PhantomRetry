# PhantomRemastered

A client-side Fabric mod for Minecraft 1.21.11 with three in-game interfaces, shared modules, HUD tools, and persistent JSON profiles.

## Build and verify

- `./gradlew build` — compile Java 21 sources, run tests, and create the remapped mod JAR.
- Output: `build/libs/PhantomRemastered-1.21.11.jar`.
- `./gradlew runClient` — launch the development client when a graphical Minecraft session is available.

## Stack

- Java 21
- Minecraft 1.21.11
- Fabric Loader 0.20.1
- Fabric API 0.141.6+1.21.11
- Fabric Loom 1.14.10
- Gradle wrapper 9.2.1

## Project map

- `src/main/java/dev/phantom/remastered/` — initializer, shared module framework, configuration, GUI, HUD modules, and utilities.
- `src/main/resources/fabric.mod.json` — client-only Fabric metadata.
- `src/test/java/` — unit tests for pure utility code.
- `README.md` — installation steps and working/unfinished feature list.

## Product behavior

Ghost, Crystal/Mace, and Rage screens share one module manager and the same settings. HUD position, module enable state, keybinds, accent color, selected GUI, and profile data are saved in Minecraft's `config/phantom-remastered/` directory.

The built-in working modules are coordinates/facing, FPS, armor durability, potion effects, toggle sprint, and practice timer. Hidden-entity overlays, automated combat, anti-cheat bypasses, and exploit features are not implemented.

## Project constraints

- Keep the target on Minecraft 1.21.11, Fabric, and Java 21.
- Do not add anti-cheat bypasses, exploit abuse, automated attacks, silent aim, or rotation spoofing.
- Do not add Sodium as a required dependency.
- Android launcher compatibility depends on the launcher providing a compatible Fabric and Java 21 runtime; it has not been device-tested.
