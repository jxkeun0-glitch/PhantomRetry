# PhantomRemastered

PhantomRemastered is a client-side Fabric mod for Minecraft **1.21.11** and **Java 21**. It includes three different in-game configuration interfaces that use the same modules and saved settings.

## Build

```sh
java -version
./gradlew build
```

The build runs the unit tests and creates:

```text
build/libs/PhantomRemastered-1.21.11.jar
```

The project uses Fabric Loom, Yarn `1.21.11+build.6`, Fabric Loader `0.20.1`, and Fabric API `0.141.6+1.21.11`.

## Install

1. Install a Java 21 Minecraft launcher and Fabric Loader for Minecraft 1.21.11.
2. Copy `PhantomRemastered-1.21.11.jar` into that instance's `mods` folder.
3. Start the Fabric 1.21.11 profile.
4. Press **Right Shift** to open the interface. Use **Change GUI** to switch among Ghost, Crystal/Mace, and Rage.

The mod has no mandatory Sodium dependency. Android launchers that support Fabric 1.21.11 and Java 21 may be able to run it; device and launcher compatibility must be verified on the target device.

## Working features

- **Three interfaces:** Ghost, Crystal/Mace, and Rage. They share the same module objects and configuration.
- **HUD modules:** coordinates and facing, FPS, armor durability, and active potion effects.
- **Toggle Sprint:** asks the local player to sprint while moving forward, when sprinting is allowed by Minecraft.
- **Practice Timer:** session timer displayed in the HUD.
- **Module controls:** enable/disable, settings, per-module reset, configurable module keybinds, and GUI keybind.
- **Profiles:** save and load multiple JSON profiles; export and import portable JSON copies.
- **Appearance:** editable accent color and adjustable HUD positions.
- **Persistence:** settings are stored in `config/phantom-remastered/` and survive restarting Minecraft.

## Not implemented / intentionally disabled

- Entity ESP, tracers through walls, chest/item ESP, and other hidden-information overlays.
- Automated attacks, aim/rotation manipulation, anti-cheat bypasses, and exploit abuse.
- Crystal and mace damage calculators, trajectory visualization, CPS/ping overlays, and draggable mouse-based HUD editing.
- The requested Android launcher compatibility is not claimed as verified; a compatible Fabric/Java runtime is required.

The interface displays module status labels (`WORKING`, `TESTING`, `PLANNED`, `DISABLED`). Only features implemented in this build are marked `WORKING`.

## Configuration

- Profiles: `config/phantom-remastered/profiles/<name>.json`
- Portable exports: `config/phantom-remastered/exports/<name>.json`
- The profile name field in the GUI is used by Save, Load, Export, and Import.
- Enter a six-digit hexadecimal color such as `#8B5CF6` and press **Apply Color**.

## License

MIT. See `LICENSE`.

## Added practice modules

- **TriggerBot Trainer**: displays the entity under the crosshair and its distance. It does not click or attack.
- **AutoMace Trainer**: displays whether a mace is equipped and shows fall-distance/timing feedback. Its timing window can be set from 1 to 10 ticks. It does not aim, click, or attack.

Both modules have normal module enable/disable controls and save their settings through the existing profile system.
